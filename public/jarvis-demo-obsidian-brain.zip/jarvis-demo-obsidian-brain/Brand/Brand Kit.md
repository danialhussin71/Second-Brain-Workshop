# Brand Kit

## Voice DNA

Clear, warm, opinionated, and practical. Prefer concrete examples over generic motivation. Avoid hype, jargon, and empty claims.

## Style

Use short paragraphs, strong first lines, and a decisive point of view. For audience language see [[Audience/ICP Profile]]. For the promise see [[Offers/Core Offer]].
