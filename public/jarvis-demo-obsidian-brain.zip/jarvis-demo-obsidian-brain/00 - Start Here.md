# Welcome to the Jarvis Demo Brain

This small vault shows how Jarvis keeps an Obsidian brain intact. Start with [[Brand/Brand Kit]], then explore [[Audience/ICP Profile]], [[Strategy/Positioning]], [[Offers/Core Offer]], and [[Content/Content Pillars]].

Every `[[wiki link]]` becomes a connection in the knowledge constellation.
