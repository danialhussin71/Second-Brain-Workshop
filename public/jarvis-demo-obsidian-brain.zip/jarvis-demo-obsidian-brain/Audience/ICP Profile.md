# ICP Profile

Independent consultants and founder-led B2B teams who have expertise but an inconsistent content system. They want authority, inbound demand, and a message their market remembers.

Their biggest frustration is publishing useful ideas without a clear through-line. The relevant answer is [[Strategy/Positioning]].
